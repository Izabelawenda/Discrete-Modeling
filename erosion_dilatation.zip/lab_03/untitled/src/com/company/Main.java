package com.company;

import java.sql.SQLOutput;
import java.util.Random;

public class Main {

    public static void main(String[] args){
        Random rand = new Random();
        int num = 2;
        int random = rand.nextInt(num);
        int tmp = random+1;
        if(tmp==1){
            System.out.println("Wylosowales wormsa z pistolem :>> ");
        }
        else if(tmp==2){
            System.out.println("Wylosowales wormsa z workiem z keszem :$ ");
        }

    }
}
