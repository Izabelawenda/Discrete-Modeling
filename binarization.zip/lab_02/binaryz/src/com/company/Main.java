package com.company;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        int[][] outputMatrix = new int[330][600];
        File file = new File("mapa.txt");
        Scanner in = new Scanner(file);
        String num;

        do{
            num=in.next();
            int help = Integer.parseInt(num);
            int border = 215;
            for(int i=0;i<330;i++) {
                for(int j=0;j<600;j++) {
                    if (help > border) {
                        help = 255;
                        outputMatrix[i][j] = help;
                    } else {
                        help = 0;
                        outputMatrix[i][j] = help;
                    }
                }
            }
        }while(in.hasNext());
        save(outputMatrix);
    }
    static void save(int[][] outputMatrix) throws IOException{

        BufferedImage paintImg = new BufferedImage(600, 330, BufferedImage.TYPE_INT_ARGB);
        Graphics g = paintImg.createGraphics();

        for(int dx = 0; dx < 330; dx++){
            for(int dy = 0; dy < 600; dy++){

                g.setColor(new Color(outputMatrix[dx][dy], outputMatrix[dx][dy], outputMatrix[dx][dy]));
                g.fillRect(dx, dy, 1, 1);
            }
        }
        ImageIO.write(paintImg, "png", new File("output.bmp"));

        g.dispose();
    }
}