package com.company;

public class Filters {
    static int [][] lowPassMask = {
            {1, 1, 1},
            {1, 1, 1},
            {1, 1, 1}
    };
    static int [][] highPassMask = {
            {-1, -1, -1},
            {-1,  9, -1},
            {-1, -1, -1}
    };
    static int [][] gaussMask ={
            {1,  4, 1},
            {4, 32, 4},
            {1,  4, 1}
    };

    static int [][] afterOperation = new int[330][600];

    static int [][] lowPassFilter(int[][] binImg)
    {
        for(int i = 1;i<binImg.length-1;i++)
        {
            for(int j = 1;j< binImg[i].length-1;j++)
            {
                int solution =  (binImg[i-1][j-1]*lowPassMask[0][0]+ binImg[i-1][j]*lowPassMask[0][1]+ binImg[i-1][j+1]*lowPassMask[0][2]+
                        binImg[i][j-1]*lowPassMask[1][0]+ binImg[i][j]*lowPassMask[1][1]+ binImg[i][j+1]*lowPassMask[1][2]+
                        binImg[i+1][j-1]*lowPassMask[2][0]+ binImg[i+1][j]*lowPassMask[2][1]+ binImg[i+1][j+1]*lowPassMask[2][2])/9;

                if(solution<0)
                    afterOperation[i][j] = 0;
                else afterOperation[i][j] = Math.min(solution, 255);
            }
        }
        return afterOperation;
    }

    static int [][] highPassFilter(int[][] binImg)
    {
        for(int i = 1;i<binImg.length-1;i++)
        {
            for(int j = 1;j< binImg[i].length-1;j++)
            {
                int solution =  binImg[i-1][j-1]*highPassMask[0][0]+ binImg[i-1][j]*highPassMask[0][1]+ binImg[i-1][j+1]*highPassMask[0][2]+
                        binImg[i][j-1]*highPassMask[1][0]+ binImg[i][j]*highPassMask[1][1]+ binImg[i][j+1]*highPassMask[1][2]+
                        binImg[i+1][j-1]*highPassMask[2][0]+ binImg[i+1][j]*highPassMask[2][1]+ binImg[i+1][j+1]*highPassMask[2][2];

                if(solution<0)
                    afterOperation[i][j] = 0;
                else afterOperation[i][j] = Math.min(solution, 255);
            }
        }
        return afterOperation;
    }

    static int [][] gaussFilter(int[][] binImg)
    {
        for(int i = 1;i<binImg.length-1;i++)
        {
            for(int j = 1;j< binImg[i].length-1;j++)
            {
                int solution =  (binImg[i-1][j-1]*gaussMask[0][0]+ binImg[i-1][j]*gaussMask[0][1]+ binImg[i-1][j+1]*gaussMask[0][2]+
                        binImg[i][j-1]*gaussMask[1][0]+ binImg[i][j]*gaussMask[1][1]+ binImg[i][j+1]*gaussMask[1][2]+
                        binImg[i+1][j-1]*gaussMask[2][0]+ binImg[i+1][j]*gaussMask[2][1]+ binImg[i+1][j+1]*gaussMask[2][2])/52;

                if(solution<0)
                    afterOperation[i][j] = 0;
                else afterOperation[i][j] = Math.min(solution, 255);
            }
        }
        return afterOperation;
    }
}

