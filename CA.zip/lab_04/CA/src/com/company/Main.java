package com.company;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        int[] arr = {0,1,0,1,1,0,1,0,1,1,0,0,1,0};
        int left = 0, mid = 0, right = 0;
        int size_of_array = arr.length;
        int[] CA = new int[size_of_array];
        System.out.println("30 rule: ");
        rule_30(arr, CA, size_of_array,left, mid, right);
        System.out.println("60 rule: ");
        rule_60(arr, CA, size_of_array,left, mid, right);
        System.out.println("90 rule: ");
        rule_90(arr, CA, size_of_array,left, mid, right);
        System.out.println("120 rule: ");
        rule_120(arr, CA, size_of_array,left, mid, right);
        System.out.println("225 rule: ");
        rule_225(arr, CA, size_of_array,left, mid, right);
    }

    static void rule_30(int[] arr, int[] CA, int size, int left, int mid, int right){
        for(int i=0;i<size;i++) {
            //checking last and first position in array
            if (i == 0) {
                left = arr[size - 1];
                right = arr[i + 1];
            } else if (i == size - 1) {
                left = arr[i - 1];
                right = arr[0];
            } else {
                left = arr[i - 1];
                right = arr[i + 1];
            }
            //application of the "30 rule"
            if(left==0 && right==0 || left==1 && right==1){
                mid=0;
                CA[i]=mid;
            }
            else if(left == 1){
                mid=0;
                CA[i]=mid;
            }
            else{
                mid=1;
                CA[i]=mid;
            }
            int hlp=CA[i];
            System.out.println(hlp);
        }
    }
    static void rule_60(int[] arr, int[] CA, int size, int left, int mid, int right){
        for(int i=0;i<size;i++) {
            //checking last and first position in array
            if (i == 0) {
                left = arr[size - 1];
                right = arr[i + 1];
            } else if (i == size - 1) {
                left = arr[i - 1];
                right = arr[0];
            } else {
                left = arr[i - 1];
                right = arr[i + 1];
            }
            //application of the "60 rule"
            if(left==0 && right==0 || left==1 && right==1){
                mid=0;
                CA[i]=mid;
            }
            else if(left==1 && mid==1 && right==0){
                mid=0;
                CA[i]=mid;
            }
            else if(left==1&&mid==0 && right==0){
                mid=1;
                CA[i]=mid;
            }
            else if(left==0&&mid==1&&right==1){
                mid=1;
                CA[i]=mid;
            }
            else if(left==0&&mid==0&&right==1){
                mid=0;
                CA[i]=mid;
            }
            int hlp=CA[i];
            System.out.println(hlp);
        }
    }
    static void rule_90(int[] arr, int[] CA, int size, int left, int mid, int right){
        for(int i=0;i<size;i++) {
            //checking last and first position in array
            if (i == 0) {
                left = arr[size - 1];
                right = arr[i + 1];
            } else if (i == size - 1) {
                left = arr[i - 1];
                right = arr[0];
            } else {
                left = arr[i - 1];
                right = arr[i + 1];
            }
            //application of the "90 rule"
            if (left == 0 && right == 0 || left == 1 && right == 1) {
                mid = 0;
                CA[i] = mid;
            } else {
                mid = 1;
                CA[i] = mid;
            }
            int hlp = CA[i];
            System.out.println(hlp);
        }
    }
    static void rule_120(int[] arr, int[] CA, int size, int left, int mid, int right){
        for(int i=0;i<size;i++) {
            //checking last and first position in array
            if (i == 0) {
                left = arr[size - 1];
                right = arr[i + 1];
            } else if (i == size - 1) {
                left = arr[i - 1];
                right = arr[0];
            } else {
                left = arr[i - 1];
                right = arr[i + 1];
            }
            //application of the "120 rule"
            if (left == 0 && right == 0 || left == 1 && right == 1 && mid ==1) {
                mid = 0;
                CA[i] = mid;
            }
            else if(left==1&&right==0){
                mid=1;
                CA[i]=mid;
            }
            else if(left==1 && right==1 && mid==0){
                mid=1;
                CA[i]=mid;
            }
            else if(left==0&&mid==1 && right==1){
                mid=1;
                CA[i]=mid;
            }
            else if(left==0&&mid==0&&right==1){
                mid=0;
                CA[i]=mid;
            }
            int hlp = CA[i];
            System.out.println(hlp);
        }
    }
    static void rule_225(int[] arr, int[] CA, int size, int left, int mid, int right){
        for(int i=0;i<size;i++) {
            //checking last and first position in array
            if (i == 0) {
                left = arr[size - 1];
                right = arr[i + 1];
            } else if (i == size - 1) {
                left = arr[i - 1];
                right = arr[0];
            } else {
                left = arr[i - 1];
                right = arr[i + 1];
            }
            //application of the "225 rule"
            if (left == 0 && right == 0 || left == 1 && right == 1) {
                mid = 1;
                CA[i] = mid;
            }
            else if(left==1&&mid==1&&right==0){
                mid = 1;
                CA[i] = mid;
            }
            else{
                mid = 0;
                CA[i] = mid;
            }
            int hlp = CA[i];
            System.out.println(hlp);
        }
    }
}
