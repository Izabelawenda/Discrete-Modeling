package com.company;

import java.io.IOException;
import java.util.Random;

public class Main {
    public static void main(String[] args) throws IOException {
        int[] arr = {0,1,0,1,1,0,1,0,1,1,0,0,1,0};
        int[][] arr2d = new int[14][14];
        Random generator = new Random();
        //Pierwsza linia przypisanie tablicy z 1 i 0, reszta komórek wypełniona zerami.
        System.out.println("BEFORE:");
        for(int i = 0;i<14;i++){
            for(int j=0;j<14;j++){
                arr2d[i][j]=generator.nextInt(2);
            }
        }
        for(int i = 1;i<13;i++){
            for(int j=1;j<13;j++){
                System.out.print(arr2d[i][j]+ " ");
            }
            System.out.println();
        }
        int left = 0, mid = 0, right = 0, top = 0, bttm = 0;
        System.out.println("AFTER: ");
        transition(arr2d,left, mid, right, top, bttm);
    }


    static void transition(int[][] arr2d, int left, int mid, int right, int top, int bttm){
        for(int i = 1;i<13;i++){
            for(int j=1;j<13;j++){
                left=arr2d[i][j-1];
                mid=arr2d[i][j];
                right=arr2d[i][j+1];
                top=arr2d[i-1][j];
                bttm=arr2d[i+1][j];
                int counter = 0;
                int[] check = {left, mid, right, top, bttm};
                for (int value : check) {
                    if (value == 1)
                        counter++;
                }
                if(mid==0 && counter==3){
                    mid=1;
                    arr2d[i][j]=mid;
                }
                else if(mid==1 && (counter==2 || counter==3)){
                    mid=1;
                    arr2d[i][j]=mid;
                }
                else if(mid==1 && counter>3){
                    mid=0;
                    arr2d[i][j]=mid;
                }
                else if(mid==1 && counter<2){
                    mid=0;
                    arr2d[i][j]=mid;
                }
                else{
                    mid=0;
                    arr2d[i][j]=mid;
                }
               System.out.print(arr2d[i][j]+ " ");
            }
            System.out.println();
        }
    }
}
