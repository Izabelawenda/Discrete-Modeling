package com.company;

import jdk.internal.icu.text.UnicodeSet;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
       List<Integer> numbers = new ArrayList<Integer>();
       File file = new File("mapa.txt");
       Scanner in = new Scanner(file);
       String num;
       do{
           num = in.next();
           int help = Integer.parseInt(num);
           Integer additive = 5;//zmiana liczby
           if(help + additive >=255){
               numbers.add(255);
           }
           if(help + additive <=0){
               numbers.add(0);
           }else{
               numbers.add(help + additive);
           }
       }while(in.hasNext());
       System.out.println(numbers);
       //System.out.println(num);
    }
}
