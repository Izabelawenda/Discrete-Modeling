package com.company;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {
    public static int[][] array = new int[330][600];

    public static void main(String[] args) throws IOException {
        String Plik = "mapa.txt";
        Read(Plik);
        //array = Filters.lowPassFilter(array);
        //array = Filters.highPassFilter(array);
        array = Filters.gaussFilter(array);
        save();
    }

    static void save() throws IOException {
        BufferedImage paintImg = new BufferedImage(330, 600, BufferedImage.TYPE_INT_ARGB);
        Graphics g = paintImg.createGraphics();

        for (int dy = 0; dy < 600; dy++) {
            for (int dx = 0; dx < 330; dx++) {
                g.setColor(new Color(array[dx][dy], array[dx][dy], array[dx][dy]));
                g.fillRect(dx, dy, 1, 1);
            }
        }
        ImageIO.write(paintImg, "png", new File("output.bmp"));
        g.dispose();
    }

    public static void Read(String file) throws IOException {
        Path filePath = Paths.get(file);
        Scanner scanner = new Scanner(filePath);
        for (int i = 0; i < 300; i++) {
            for (int j = 0; j < 600; j++) {
                array[i][j] = scanner.nextInt();
            }
        }
    }

    public static void Binarization() {
        for (int i = 0; i < 330; i++) {
            for (int j = 0; j < 600; j++) {
                if (array[i][j] < 205) {
                    array[i][j] = 0;
                } else array[i][j] = 255;
            }
        }
    }

    public static void Save(String newFile) throws FileNotFoundException {
        PrintWriter newmap = new PrintWriter("newmap.txt");
        for (int i = 0; i < 330; i++) {
            for (int j = 0; j < 600; j++) {
                newmap.print(array[i][j]);
                newmap.print("\t");
            }
        }
    }

    static int[][] dilatation(int[][] array) {
        int[][] output = new int[330][600];
        for (int y = 0; y < 600; y++) {
            for (int x = 0; x < 330; x++) {

                boolean equal = false;
                for (int dy = -1; dy <= 1 && !equal; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int px = x + dx;
                        int py = y + dy;
                        if (px >= 0 && px < 330 && py >= 0 && py < 600) {
                            if (array[px][py] == 255) {
                                equal = true;
                                break;
                            }
                        }
                    }
                }
                if (equal) {

                    output[x][y] = 255;
                } else {
                    output[x][y] = 0;
                }
            }
        }
        return output;
    }

    static int[][] erosion(int[][] array) {
        int[][] output = new int[330][600];
        for (int y = 0; y < 600; y++) {
            for (int x = 0; x < 330; x++) {
                boolean equal = false;
                for (int dy = -1; dy <= 1 && !equal; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int px = x + dx;
                        int py = y + dy;
                        if (px >= 0 && px < 330 && py >= 0 && py < 600) {
                            if (array[px][py] == 0) {
                                equal = true;
                                break;
                            }
                        }
                    }
                }
                if (equal) {
                    output[x][y] = 0;
                } else {
                    output[x][y] = array[x][y];
                }
            }
        }
        return output;
    }
}